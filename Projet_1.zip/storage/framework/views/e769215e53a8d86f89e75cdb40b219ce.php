<div class="card h-100 shadow-sm border-0 position-relative overflow-hidden" data-card-id="<?php echo e($id); ?>">
    <div class="card-header border-0 text-white text-center py-3" style="background: <?php echo e($gradientHeader); ?>">
        <h6 class="card-title mb-0 fw-bold"><?php echo e($name); ?></h6>
    </div>

    <?php if($imageUrl): ?>
        <img src="<?php echo e($imageUrl); ?>" class="card-img-top" alt="<?php echo e($name); ?>" style="height: <?php echo e($cardImageHeight); ?>; object-fit: cover;">
    <?php else: ?>
        <div class="d-flex align-items-center justify-content-center text-white fs-1 fw-bold" style="height: <?php echo e($cardImageHeight); ?>; background: <?php echo e($gradientBackground); ?>;">
            <i class="bi bi-stars opacity-75"></i>
        </div>
    <?php endif; ?>

    <div class="card-body d-flex flex-column">
        <p class="card-text text-muted flex-grow-1 <?php echo e(Auth::check() ? '' : 'fs-5 lh-base'); ?>">
            <?php echo e($description); ?>

        </p>

        <div class="d-flex align-items-center mb-3">
            <small class="text-muted me-2">
                <?php echo e(app()->getLocale() == 'en' ? 'Colors:' : 'Couleurs:'); ?>

            </small>
            <div class="d-flex gap-2">
                <div class="rounded-circle border border-2 border-white shadow-sm"
                     style="width: <?php echo e($colorIndicatorSize); ?>; height: <?php echo e($colorIndicatorSize); ?>; background-color: <?php echo e($primaryColor); ?>;"
                     data-bs-toggle="tooltip"
                     data-bs-placement="top"
                     title="<?php echo e($colorTooltipPrimary); ?>"></div>
                <div class="rounded-circle border border-2 border-white shadow-sm"
                     style="width: <?php echo e($colorIndicatorSize); ?>; height: <?php echo e($colorIndicatorSize); ?>; background-color: <?php echo e($secondaryColor); ?>;"
                     data-bs-toggle="tooltip"
                     data-bs-placement="top"
                     title="<?php echo e($colorTooltipSecondary); ?>"></div>
            </div>
        </div>

        <div class="d-flex gap-2">
            <?php if(auth()->guard()->check()): ?>
                <!-- Bouton Voir (pour tous) -->
                <a href="<?php echo e(route('univers.show', $id)); ?>" class="btn btn-outline-info btn-sm">
                    <i class="bi bi-eye me-1"></i>
                    <?php echo e(app()->getLocale() == 'en' ? 'View' : 'Voir'); ?>

                </a>

                <!-- Bouton Favoris -->
                <button class="btn btn-outline-warning btn-sm favorite-btn"
                        data-univers-id="<?php echo e($id); ?>"
                        data-is-favorite="<?php echo e(Auth::user()->hasFavorite($id) ? 'true' : 'false'); ?>">
                    <i class="bi <?php echo e(Auth::user()->hasFavorite($id) ? 'bi-heart-fill' : 'bi-heart'); ?> me-1"></i>
                    <span class="favorite-text">
                        <?php echo e(Auth::user()->hasFavorite($id)
                            ? (app()->getLocale() == 'en' ? 'Favorited' : 'Favori')
                            : (app()->getLocale() == 'en' ? 'Favorite' : 'Favoris')); ?>

                    </span>
                </button>

                <!-- Bouton Modifier (admin seulement) -->
                <?php if(Auth::check() && Auth::user()->role === 'admin'): ?>
                    <a href="<?php echo e(route('univers.edit', $id)); ?>" class="btn btn-outline-warning btn-sm">
                        <i class="bi bi-pencil me-1"></i>
                        <?php echo e(app()->getLocale() == 'en' ? 'Edit' : 'Modifier'); ?>

                    </a>
                <?php endif; ?>
            <?php else: ?>
                <!-- Visiteurs non connectés -->
                <a href="<?php echo e(route('univers.show', $id)); ?>" class="btn btn-outline-secondary btn-lg w-100">
                    <i class="bi bi-eye me-1"></i>
                    <?php echo e(app()->getLocale() == 'en' ? 'View card' : 'Voir l\'univers'); ?>

                </a>
            <?php endif; ?>
        </div>
    </div>

    <?php if($logoUrl): ?>
    <div class="position-absolute top-0 end-0 m-3" style="z-index: 10;">
        <img src="<?php echo e($logoUrl); ?>" alt="Logo <?php echo e($name); ?>"
             class="rounded-circle border border-3 border-white shadow"
             style="width: <?php echo e($logoSize); ?>; height: <?php echo e($logoSize); ?>; object-fit: cover;">
    </div>
    <?php endif; ?>
</div>
<?php /**PATH C:\code\Projet_1\resources\views/components/carte.blade.php ENDPATH**/ ?>