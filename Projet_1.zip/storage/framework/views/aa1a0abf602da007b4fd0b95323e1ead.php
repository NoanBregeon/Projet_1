<?php $__env->startSection('title', app()->getLocale() == 'en' ? 'Reset Password' : 'Réinitialiser le mot de passe'); ?>
<?php $__env->startSection('content'); ?>

<div class="d-flex justify-content-center align-items-center" style="min-height: calc(100vh - 120px);">
    <div class="auth-container">
        <div class="text-center mb-3">
            <div class="mb-3">
                <i class="bi bi-shield-lock display-1 text-success"></i>
            </div>
            <h1 class="auth-title">
                <?php echo e(app()->getLocale() == 'en' ? 'Reset Password' : 'Réinitialiser le mot de passe'); ?>

            </h1>
            <p class="auth-subtitle">
                <?php echo e(app()->getLocale() == 'en' ?
                    'Enter your new password below to complete the reset process.' :
                    'Saisissez votre nouveau mot de passe ci-dessous pour terminer la réinitialisation.'); ?>

            </p>
        </div>

        <form method="POST" action="<?php echo e(route('password.store')); ?>">
            <?php echo csrf_field(); ?>
            <input type="hidden" name="token" value="<?php echo e($request->route('token')); ?>">

            <!-- Email (en lecture seule) -->
            <div class="form-group">
                <div class="input-icon">
                    <i class="bi bi-envelope"></i>
                </div>
                <div class="form-field">
                    <label class="auth-form-label" for="email">Email</label>
                    <input id="email" class="auth-form-input" type="email" name="email"
                           value="<?php echo e(old('email', $request->email)); ?>" required readonly
                           style="background-color: #f8f9fa;">
                    <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <div class="text-danger mt-1 small"><?php echo e($message); ?></div>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>
            </div>

            <!-- Nouveau mot de passe -->
            <div class="form-group">
                <div class="input-icon">
                    <i class="bi bi-lock"></i>
                </div>
                <div class="form-field">
                    <label class="auth-form-label" for="password">
                        <?php echo e(app()->getLocale() == 'en' ? 'New Password' : 'Nouveau mot de passe'); ?>

                    </label>
                    <input id="password" class="auth-form-input" type="password" name="password" required autofocus>
                    <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <div class="text-danger mt-1 small"><?php echo e($message); ?></div>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>
            </div>

            <!-- Confirmation -->
            <div class="form-group">
                <div class="input-icon">
                    <i class="bi bi-lock-fill"></i>
                </div>
                <div class="form-field">
                    <label class="auth-form-label" for="password_confirmation">
                        <?php echo e(app()->getLocale() == 'en' ? 'Confirm Password' : 'Confirmer le mot de passe'); ?>

                    </label>
                    <input id="password_confirmation" class="auth-form-input" type="password"
                           name="password_confirmation" required>
                    <?php $__errorArgs = ['password_confirmation'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <div class="text-danger mt-1 small"><?php echo e($message); ?></div>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>
            </div>

            <button type="submit" class="auth-form-button">
                <i class="bi bi-check-circle me-2"></i>
                <?php echo e(app()->getLocale() == 'en' ? 'Reset Password' : 'Réinitialiser le mot de passe'); ?>

            </button>
        </form>

        <div class="text-center mt-3">
            <a href="<?php echo e(route('login')); ?>" class="auth-link">
                <i class="bi bi-arrow-left me-1"></i>
                <?php echo e(app()->getLocale() == 'en' ? 'Back to login' : 'Retour à la connexion'); ?>

            </a>
        </div>
    </div>
</div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\code\Projet_1\resources\views/auth/reset-password.blade.php ENDPATH**/ ?>