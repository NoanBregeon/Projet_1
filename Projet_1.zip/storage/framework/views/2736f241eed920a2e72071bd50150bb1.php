<?php $__env->startSection('title', app()->getLocale() == 'en' ? 'Verify Email' : 'Vérifier l\'email'); ?>
<?php $__env->startSection('content'); ?>

<div class="d-flex justify-content-center align-items-center" style="min-height: calc(100vh - 120px);">
    <div class="auth-container">
        <div class="text-center mb-4">
            <div class="mb-3">
                <i class="bi bi-envelope-check display-1 text-primary"></i>
            </div>
            <h1 class="auth-title">
                <?php echo e(app()->getLocale() == 'en' ? 'Verify Your Email' : 'Vérifiez votre email'); ?>

            </h1>
            <p class="auth-subtitle">
                <?php echo e(app()->getLocale() == 'en' ?
                    'We\'ve sent a verification email to your address. Please check your inbox and click the verification link to activate your account.' :
                    'Nous avons envoyé un email de vérification à votre adresse. Veuillez vérifier votre boîte de réception et cliquer sur le lien de vérification pour activer votre compte.'); ?>

            </p>
            <div class="alert alert-info">
                <i class="bi bi-info-circle me-2"></i>
                <strong><?php echo e(app()->getLocale() == 'en' ? 'Email sent to:' : 'Email envoyé à :'); ?></strong>
                <?php echo e(auth()->user()->email); ?>

            </div>
        </div>

        <?php if(session('status') == 'verification-link-sent'): ?>
            <div class="alert alert-success">
                <i class="bi bi-check-circle me-2"></i>
                <?php echo e(app()->getLocale() == 'en' ? 'A new verification link has been sent to your email address!' : 'Un nouveau lien de vérification a été envoyé à votre adresse email !'); ?>

            </div>
        <?php endif; ?>

        <div class="d-flex gap-3 flex-column">
            <!-- Renvoyer le lien -->
            <form method="POST" action="<?php echo e(route('verification.send')); ?>">
                <?php echo csrf_field(); ?>
                <button type="submit" class="auth-form-button">
                    <i class="bi bi-envelope me-2"></i>
                    <?php echo e(app()->getLocale() == 'en' ? 'Resend Verification Email' : 'Renvoyer l\'email de vérification'); ?>

                </button>
            </form>

            <!-- Déconnexion -->
            <form method="POST" action="<?php echo e(route('logout')); ?>">
                <?php echo csrf_field(); ?>
                <button type="submit" class="btn btn-outline-secondary w-100">
                    <i class="bi bi-box-arrow-right me-2"></i>
                    <?php echo e(app()->getLocale() == 'en' ? 'Log Out' : 'Se déconnecter'); ?>

                </button>
            </form>
        </div>

        <div class="text-center mt-4">
            <small class="text-muted">
                <?php echo e(app()->getLocale() == 'en' ? 'Check your spam folder if you don\'t see the email in your inbox.' : 'Vérifiez votre dossier spam si vous ne voyez pas l\'email dans votre boîte de réception.'); ?>

            </small>
        </div>

        <div class="text-center mt-3">
            <a href="<?php echo e(url('/')); ?>" class="auth-link">
                <i class="bi bi-house me-1"></i>
                <?php echo e(app()->getLocale() == 'en' ? 'Back to home' : 'Retour à l\'accueil'); ?>

            </a>
        </div>
    </div>
</div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\code\Projet_1\resources\views/auth/verify-email.blade.php ENDPATH**/ ?>