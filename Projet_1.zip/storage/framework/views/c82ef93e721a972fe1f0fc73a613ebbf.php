<!DOCTYPE html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">

    <title><?php echo e(app()->getLocale() == 'en' ? 'Login' : 'Connexion'); ?></title>

    <!-- Script anti-flash -->
    <script>
        (function() {
            const savedTheme = localStorage.getItem('theme');
            if (savedTheme === 'dark') {
                document.documentElement.setAttribute('data-theme', 'dark');
                document.documentElement.style.backgroundColor = '#343a40';
                document.documentElement.style.color = '#ffffff';
            }
        })();
    </script>

    <!-- Bootstrap CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.10.0/font/bootstrap-icons.css" rel="stylesheet">
    <link href="<?php echo e(asset('css/app.css')); ?>" rel="stylesheet">
</head>
<body>
    <!-- Bouton de bascule thème -->
    <button id="theme-toggle" class="theme-toggle">
        <i id="theme-icon" class="bi bi-moon-fill"></i>
    </button>

    <!-- Sélecteur de langue -->
    <div class="language-selector">
        <div class="dropdown">
            <button class="btn btn-outline-secondary btn-sm dropdown-toggle" type="button" data-bs-toggle="dropdown">
                <i class="bi bi-globe me-1"></i>
                <?php echo e(app()->getLocale() == 'fr' ? 'FR' : 'EN'); ?>

            </button>
            <ul class="dropdown-menu">
                <li>
                    <a class="dropdown-item <?php echo e(app()->getLocale() == 'fr' ? 'active' : ''); ?>"
                       href="<?php echo e(route('language.switch', 'fr')); ?>">
                        <i class="bi bi-flag me-2"></i>Français
                    </a>
                </li>
                <li>
                    <a class="dropdown-item <?php echo e(app()->getLocale() == 'en' ? 'active' : ''); ?>"
                       href="<?php echo e(route('language.switch', 'en')); ?>">
                        <i class="bi bi-flag me-2"></i>English
                    </a>
                </li>
            </ul>
        </div>
    </div>

    <div class="d-flex justify-content-center align-items-center" style="min-height: calc(100vh - 120px);">
        <div class="auth-container">
            <div class="text-center mb-3">
                <h1 class="auth-title">
                    <?php echo e(app()->getLocale() == 'en' ? 'Login' : 'Connexion'); ?>

                </h1>
                <p class="auth-subtitle">
                    <?php echo e(app()->getLocale() == 'en' ? 'Access your space to manage your cards' : 'Accédez à votre espace pour gérer vos cartes'); ?>

                </p>
            </div>

            <!-- Affichage des erreurs de session -->
            <?php if (isset($component)) { $__componentOriginal7c1bf3a9346f208f66ee83b06b607fb5 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal7c1bf3a9346f208f66ee83b06b607fb5 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.auth-session-status','data' => ['class' => 'mb-4','status' => session('status')]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('auth-session-status'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['class' => 'mb-4','status' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute(session('status'))]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal7c1bf3a9346f208f66ee83b06b607fb5)): ?>
<?php $attributes = $__attributesOriginal7c1bf3a9346f208f66ee83b06b607fb5; ?>
<?php unset($__attributesOriginal7c1bf3a9346f208f66ee83b06b607fb5); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal7c1bf3a9346f208f66ee83b06b607fb5)): ?>
<?php $component = $__componentOriginal7c1bf3a9346f208f66ee83b06b607fb5; ?>
<?php unset($__componentOriginal7c1bf3a9346f208f66ee83b06b607fb5); ?>
<?php endif; ?>

            <form method="POST" action="<?php echo e(route('login')); ?>">
                <?php echo csrf_field(); ?>

                <!-- Email -->
                <div class="form-group">
                    <div class="input-icon">
                        <i class="bi bi-envelope"></i>
                    </div>
                    <div class="form-field">
                        <label class="auth-form-label" for="email">Email</label>
                        <input id="email" class="auth-form-input" type="email" name="email"
                               value="<?php echo e(old('email')); ?>" required autofocus
                               placeholder="<?php echo e(old('email')); ?>">
                        <?php if (isset($component)) { $__componentOriginalf94ed9c5393ef72725d159fe01139746 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalf94ed9c5393ef72725d159fe01139746 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.input-error','data' => ['messages' => $errors->get('email'),'class' => 'mt-2']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('input-error'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['messages' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($errors->get('email')),'class' => 'mt-2']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalf94ed9c5393ef72725d159fe01139746)): ?>
<?php $attributes = $__attributesOriginalf94ed9c5393ef72725d159fe01139746; ?>
<?php unset($__attributesOriginalf94ed9c5393ef72725d159fe01139746); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalf94ed9c5393ef72725d159fe01139746)): ?>
<?php $component = $__componentOriginalf94ed9c5393ef72725d159fe01139746; ?>
<?php unset($__componentOriginalf94ed9c5393ef72725d159fe01139746); ?>
<?php endif; ?>
                    </div>
                </div>

                <!-- Mot de passe -->
                <div class="form-group">
                    <div class="input-icon">
                        <i class="bi bi-lock"></i>
                    </div>
                    <div class="form-field">
                        <label class="auth-form-label" for="password">
                            <?php echo e(app()->getLocale() == 'en' ? 'Password' : 'Mot de passe'); ?>

                        </label>
                        <input id="password" class="auth-form-input" type="password" name="password" required>
                        <?php if (isset($component)) { $__componentOriginalf94ed9c5393ef72725d159fe01139746 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalf94ed9c5393ef72725d159fe01139746 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.input-error','data' => ['messages' => $errors->get('password'),'class' => 'mt-2']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('input-error'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['messages' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($errors->get('password')),'class' => 'mt-2']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalf94ed9c5393ef72725d159fe01139746)): ?>
<?php $attributes = $__attributesOriginalf94ed9c5393ef72725d159fe01139746; ?>
<?php unset($__attributesOriginalf94ed9c5393ef72725d159fe01139746); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalf94ed9c5393ef72725d159fe01139746)): ?>
<?php $component = $__componentOriginalf94ed9c5393ef72725d159fe01139746; ?>
<?php unset($__componentOriginalf94ed9c5393ef72725d159fe01139746); ?>
<?php endif; ?>
                    </div>
                </div>

                <!-- Se souvenir de moi -->
                <div class="form-inline mb-3">
                    <input id="remember_me" type="checkbox" class="form-check-input" name="remember">
                    <label for="remember_me" class="form-check-label ms-2">
                        <?php echo e(app()->getLocale() == 'en' ? 'Remember me' : 'Se souvenir de moi'); ?>

                    </label>
                </div>

                <button type="submit" class="auth-form-button">
                    <?php echo e(app()->getLocale() == 'en' ? 'Log in' : 'Se connecter'); ?>

                </button>

                <?php if(Route::has('password.request')): ?>
                    <div class="text-center mt-3">
                        <a class="auth-link" href="<?php echo e(route('password.request')); ?>">
                            <?php echo e(app()->getLocale() == 'en' ? 'Forgot your password?' : 'Mot de passe oublié ?'); ?>

                        </a>
                    </div>
                <?php endif; ?>

                <div class="text-center mt-3">
                    <a href="<?php echo e(route('register')); ?>" class="auth-link">
                        <?php echo e(app()->getLocale() == 'en' ? 'Create an account' : 'Créer un compte'); ?>

                    </a>
                </div>

                <div class="auth-back">
                    <a href="<?php echo e(url('/')); ?>" class="btn btn-link">
                        <i class="bi bi-house me-1"></i>
                        <?php echo e(app()->getLocale() == 'en' ? 'Back to home' : 'Retour à l\'accueil'); ?>

                    </a>
                </div>
            </form>
        </div>
    </div>

    <!-- Bootstrap JS -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
    <script src="<?php echo e(asset('js/app.js')); ?>"></script>
</body>
</html>
<?php /**PATH C:\code\Projet_1\resources\views/auth/login.blade.php ENDPATH**/ ?>