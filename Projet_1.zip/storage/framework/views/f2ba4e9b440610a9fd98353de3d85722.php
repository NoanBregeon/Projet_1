<!DOCTYPE html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">

    <title><?php echo e(config('app.name', 'Laravel')); ?></title>

    <!-- Script anti-flash -->
    <script>
        (function() {
            const savedTheme = localStorage.getItem('theme');
            if (savedTheme === 'dark') {
                document.documentElement.setAttribute('data-theme', 'dark');
                document.documentElement.style.backgroundColor = '#1e293b';
                document.documentElement.style.color = '#f8fafc';
            }
        })();
    </script>

    <!-- Bootstrap Icons -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.0/font/bootstrap-icons.css" rel="stylesheet">
    
    <!-- Vite Assets -->
    <?php echo app('Illuminate\Foundation\Vite')(['resources/css/app.css', 'resources/js/app.js']); ?>
</head>
<body>
    <!-- Header fixe avec tous les contrôles -->
    <div class="header-controls">
        <?php if(auth()->guard()->check()): ?>
            <!-- Lien vers les favoris -->
            <a href="<?php echo e(route('favorites.index')); ?>" 
               class="btn <?php echo e(request()->routeIs('favorites.index') ? 'btn-warning' : 'btn-outline-warning'); ?> btn-sm me-2">
                <i class="bi bi-heart-fill me-1"></i>
                <?php echo e(app()->getLocale() == 'en' ? 'Favorites' : 'Favoris'); ?>

                <?php if(Auth::user()->favorites()->count() > 0): ?>
                    <span class="badge <?php echo e(request()->routeIs('favorites.index') ? 'bg-dark' : 'bg-warning text-dark'); ?> ms-1">
                        <?php echo e(Auth::user()->favorites()->count()); ?>

                    </span>
                <?php endif; ?>
            </a>
            
            <!-- Lien vers l'accueil si on est sur les favoris -->
            <?php if(request()->routeIs('favorites.index')): ?>
                <a href="<?php echo e(url('/')); ?>" class="btn btn-outline-primary btn-sm me-2">
                    <i class="bi bi-house me-1"></i>
                    <?php echo e(app()->getLocale() == 'en' ? 'Home' : 'Accueil'); ?>

                </a>
            <?php endif; ?>
        <?php endif; ?>

        <!-- Sélecteur de langue -->
        <div class="language-selector">
            <div class="dropdown">
                <button class="btn btn-outline-secondary btn-sm dropdown-toggle" type="button" data-bs-toggle="dropdown">
                    <i class="bi bi-globe me-1"></i>
                    <?php echo e(app()->getLocale() == 'fr' ? 'FR' : 'EN'); ?>

                </button>
                <ul class="dropdown-menu">
                    <li>
                        <a class="dropdown-item <?php echo e(app()->getLocale() == 'fr' ? 'active' : ''); ?>"
                           href="<?php echo e(route('language.switch', 'fr')); ?>">
                            <i class="bi bi-flag me-2"></i>Français
                        </a>
                    </li>
                    <li>
                        <a class="dropdown-item <?php echo e(app()->getLocale() == 'en' ? 'active' : ''); ?>"
                           href="<?php echo e(route('language.switch', 'en')); ?>">
                            <i class="bi bi-flag me-2"></i>English
                        </a>
                    </li>
                </ul>
            </div>
        </div>

        <!-- Bouton de bascule thème -->
        <button id="theme-toggle" class="theme-toggle">
            <i id="theme-icon" class="bi bi-moon-fill"></i>
        </button>
    </div>

    <!-- Contenu principal avec espace pour le header -->
    <main class="main-content container px-4 py-6">
        <?php echo $__env->yieldContent('content'); ?>
    </main>
</body>
</html>
<?php /**PATH C:\code\Projet_1\resources\views/layouts/app.blade.php ENDPATH**/ ?>