<?php $__env->startSection('title', app()->getLocale() == 'en' ? 'Forgot Password' : 'Mot de passe oublié'); ?>
<?php $__env->startSection('content'); ?>

<div class="d-flex justify-content-center align-items-center" style="min-height: calc(100vh - 120px);">
    <div class="auth-container">
        <div class="text-center mb-3">
            <div class="mb-3">
                <i class="bi bi-key display-1 text-warning"></i>
            </div>
            <h1 class="auth-title">
                <?php echo e(app()->getLocale() == 'en' ? 'Forgot Password?' : 'Mot de passe oublié ?'); ?>

            </h1>
            <p class="auth-subtitle">
                <?php echo e(app()->getLocale() == 'en' ?
                    'No problem. Just let us know your email address and we will email you a password reset link.' :
                    'Pas de problème. Indiquez-nous simplement votre adresse email et nous vous enverrons un lien de réinitialisation.'); ?>

            </p>
        </div>

        <?php if(session('status')): ?>
            <div class="alert alert-success">
                <i class="bi bi-check-circle me-2"></i>
                <?php echo e(session('status')); ?>

            </div>
        <?php endif; ?>

        <form method="POST" action="<?php echo e(route('password.email')); ?>">
            <?php echo csrf_field(); ?>

            <div class="form-group">
                <div class="input-icon">
                    <i class="bi bi-envelope"></i>
                </div>
                <div class="form-field">
                    <label class="auth-form-label" for="email">Email</label>
                    <input id="email" class="auth-form-input" type="email" name="email"
                           value="<?php echo e(old('email')); ?>" required autofocus>
                    <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <div class="text-danger mt-1"><?php echo e($message); ?></div>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>
            </div>

            <button type="submit" class="auth-form-button">
                <i class="bi bi-send me-2"></i>
                <?php echo e(app()->getLocale() == 'en' ? 'Email Password Reset Link' : 'Envoyer le lien de réinitialisation'); ?>

            </button>
        </form>

        <div class="text-center mt-3">
            <a href="<?php echo e(route('login')); ?>" class="auth-link">
                <?php echo e(app()->getLocale() == 'en' ? 'Back to login' : 'Retour à la connexion'); ?>

            </a>
        </div>
    </div>
</div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\code\Projet_1\resources\views/auth/forgot-password.blade.php ENDPATH**/ ?>