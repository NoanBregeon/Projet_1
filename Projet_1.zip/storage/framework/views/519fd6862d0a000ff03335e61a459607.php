<?php echo e($slot); ?>

<?php /**PATH C:\code\Projet_1\vendor\laravel\framework\src\Illuminate\Mail/resources/views/text/subcopy.blade.php ENDPATH**/ ?>