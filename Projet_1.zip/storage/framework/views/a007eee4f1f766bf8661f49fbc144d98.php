<?php $__env->startSection('title', 'Ma Collection de Cartes'); ?>
<?php $__env->startSection('content'); ?>

<?php if(session('message')): ?>
    <?php if (isset($component)) { $__componentOriginal0296bf63334863c1b9c82a8f67a25f83 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal0296bf63334863c1b9c82a8f67a25f83 = $attributes; } ?>
<?php $component = App\View\Components\Alerte::resolve(['message' => session('message'),'type' => 'success','icon' => 'bi-check-circle'] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('alerte'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\Alerte::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal0296bf63334863c1b9c82a8f67a25f83)): ?>
<?php $attributes = $__attributesOriginal0296bf63334863c1b9c82a8f67a25f83; ?>
<?php unset($__attributesOriginal0296bf63334863c1b9c82a8f67a25f83); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal0296bf63334863c1b9c82a8f67a25f83)): ?>
<?php $component = $__componentOriginal0296bf63334863c1b9c82a8f67a25f83; ?>
<?php unset($__componentOriginal0296bf63334863c1b9c82a8f67a25f83); ?>
<?php endif; ?>
<?php endif; ?>

<?php if(auth()->guard()->check()): ?>
<div class="mb-4 text-end d-flex justify-content-end gap-2 align-items-center">
    <!-- Indicateur de rôle -->
    <?php if(Auth::check() && Auth::user()->role === 'admin'): ?>
        <span class="badge bg-danger me-2">
            <i class="bi bi-shield-check me-1"></i>
            <?php echo e(app()->getLocale() == 'en' ? 'Administrator' : 'Administrateur'); ?>

        </span>
    <?php else: ?>
        <span class="badge bg-info me-2">
            <i class="bi bi-person me-1"></i>
            <?php echo e(app()->getLocale() == 'en' ? 'User' : 'Utilisateur'); ?>

        </span>
    <?php endif; ?>

    <!-- Bouton pour créer une carte -->
    <a href="<?php echo e(route('univers.create')); ?>" class="btn btn-primary me-2">
        <i class="bi bi-plus-lg me-1"></i>
        <?php echo e(app()->getLocale() == 'en' ? 'Create Card' : 'Créer une carte'); ?>

    </a>

    <!-- Formulaire de déconnexion -->
    <form method="POST" action="<?php echo e(route('logout')); ?>">
        <?php echo csrf_field(); ?>
        <button type="submit" class="btn btn-outline-danger">
            <i class="bi bi-box-arrow-right me-1"></i>
            <?php echo e(app()->getLocale() == 'en' ? 'Logout' : 'Déconnexion'); ?>

        </button>
    </form>
</div>
<?php endif; ?>

<?php if(auth()->guard()->guest()): ?>
<div class="mb-4 text-end">
    <a href="<?php echo e(route('login')); ?>" class="btn btn-outline-primary me-2">
        <i class="bi bi-person-circle me-1"></i>
        <?php echo e(app()->getLocale() == 'en' ? 'Login' : 'Connexion'); ?>

    </a>
    <a href="<?php echo e(route('register')); ?>" class="btn btn-outline-success">
        <i class="bi bi-person-plus me-1"></i>
        <?php echo e(app()->getLocale() == 'en' ? 'Sign Up' : 'Créer un compte'); ?>

    </a>
</div>
<?php endif; ?>

<div class="text-center mb-5">
    <h1 class="display-4 fw-bold text-dark mb-2">
        <?php echo e(app()->getLocale() == 'en' ? 'My Card Collection' : 'Ma Collection de Cartes'); ?>

    </h1>
    <p class="lead text-muted">
        <?php echo e(app()->getLocale() == 'en' ? 'Explore and manage your personal collection' : 'Explorez et gérez votre collection personnelle'); ?>

    </p>
</div>

<div class="row g-4">
    <?php $__empty_1 = true; $__currentLoopData = $processedUnivers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $univers): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
    <div class="col-md-6 col-lg-4">
        <?php if (isset($component)) { $__componentOriginal92e75aaf20b8ba8b153e8e2ef5cb67a0 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal92e75aaf20b8ba8b153e8e2ef5cb67a0 = $attributes; } ?>
<?php $component = App\View\Components\Carte::resolve(['id' => $univers['id'],'name' => $univers['name'],'gradientHeader' => $univers['gradient_header'],'imageUrl' => $univers['image_url'],'cardImageHeight' => $viewConfig['styles']['card_image_height'],'gradientBackground' => $univers['gradient_background'],'description' => $univers['truncated_description'],'primaryColor' => $univers['primary_color'],'secondaryColor' => $univers['secondary_color'],'colorIndicatorSize' => $viewConfig['styles']['color_indicator_size'],'colorTooltipPrimary' => $univers['color_tooltips']['primary'],'colorTooltipSecondary' => $univers['color_tooltips']['secondary'],'logoUrl' => $univers['logo_url'],'logoSize' => $viewConfig['styles']['logo_size']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('carte'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\Carte::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal92e75aaf20b8ba8b153e8e2ef5cb67a0)): ?>
<?php $attributes = $__attributesOriginal92e75aaf20b8ba8b153e8e2ef5cb67a0; ?>
<?php unset($__attributesOriginal92e75aaf20b8ba8b153e8e2ef5cb67a0); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal92e75aaf20b8ba8b153e8e2ef5cb67a0)): ?>
<?php $component = $__componentOriginal92e75aaf20b8ba8b153e8e2ef5cb67a0; ?>
<?php unset($__componentOriginal92e75aaf20b8ba8b153e8e2ef5cb67a0); ?>
<?php endif; ?>
    </div>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
    <div class="col-12">
        <div class="text-center mt-5">
            <div class="mb-4">
                <i class="bi bi-collection display-1 text-muted"></i>
            </div>
            <h3 class="text-muted mb-3"><?php echo e($viewConfig['messages']['empty_title']); ?></h3>
            <p class="text-muted mb-4"><?php echo e($viewConfig['messages']['empty_subtitle']); ?></p>
            <?php if(auth()->guard()->check()): ?>
            <a href="<?php echo e(route('univers.create')); ?>" class="btn btn-primary btn-lg">
                <i class="bi bi-plus-lg me-2"></i><?php echo e($viewConfig['messages']['empty_button']); ?>

            </a>
            <?php endif; ?>
        </div>
    </div>
    <?php endif; ?>

    <?php if($processedUnivers->isNotEmpty() && Auth::check()): ?>
    <div class="col-md-6 col-lg-4">
        <div class="card h-100 border-2 border-dashed border-primary bg-light">
            <div class="card-body d-flex flex-column justify-content-center align-items-center text-center p-5">
                <div class="mb-3">
                    <i class="bi bi-plus-circle display-1 text-primary"></i>
                </div>
                <h5 class="card-title text-primary fw-bold mb-3"><?php echo e($viewConfig['messages']['add_title']); ?></h5>
                <p class="card-text text-muted mb-4"><?php echo e($viewConfig['messages']['add_subtitle']); ?></p>
                <a href="<?php echo e(route('univers.create')); ?>" class="btn btn-primary btn-lg">
                    <i class="bi bi-plus-lg me-2"></i><?php echo e($viewConfig['messages']['add_button']); ?>

                </a>
            </div>
        </div>
    </div>
    <?php endif; ?>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\code\Projet_1\resources\views/vue.blade.php ENDPATH**/ ?>