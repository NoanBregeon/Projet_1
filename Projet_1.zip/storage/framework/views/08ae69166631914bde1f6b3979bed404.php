<?php $__env->startSection('title', $isEdit ? 'Modifier la carte' : 'Ajouter une carte'); ?>
<?php $__env->startSection('content'); ?>

<!-- Bouton de bascule thème -->
<button id="theme-toggle" class="theme-toggle">
    <i id="theme-icon" class="bi bi-moon-fill"></i>
</button>

<!-- Sélecteur de langue -->
<div class="language-selector">
    <div class="dropdown">
        <button class="btn btn-outline-secondary btn-sm dropdown-toggle" type="button" data-bs-toggle="dropdown">
            <i class="bi bi-globe me-1"></i>
            <?php echo e(app()->getLocale() == 'fr' ? 'FR' : 'EN'); ?>

        </button>
        <ul class="dropdown-menu">
            <li>
                <a class="dropdown-item <?php echo e(app()->getLocale() == 'fr' ? 'active' : ''); ?>"
                   href="<?php echo e(route('language.switch', 'fr')); ?>">
                    <i class="bi bi-flag me-2"></i>Français
                </a>
            </li>
            <li>
                <a class="dropdown-item <?php echo e(app()->getLocale() == 'en' ? 'active' : ''); ?>"
                   href="<?php echo e(route('language.switch', 'en')); ?>">
                    <i class="bi bi-flag me-2"></i>English
                </a>
            </li>
        </ul>
    </div>
</div>

<div class="row justify-content-center">
    <div class="col-lg-10">
        <div class="mb-4">
            <a href="<?php echo e(url('/')); ?>" class="btn btn-link text-decoration-none">
                <i class="bi bi-arrow-left"></i>
                <?php echo e(app()->getLocale() == 'en' ? 'Back to my collection' : 'Retour à ma collection'); ?>

            </a>
        </div>

        <div class="card shadow">
            <div class="card-body p-4">
                <div class="text-center py-4 rounded-3 mb-4 text-white" style="background: <?php echo e($formData['gradients']['header']); ?>;">
                    <h1 class="h3 fw-bold">
                        <?php echo e($isEdit ?
                            (app()->getLocale() == 'en' ? 'Edit ' . $formData['name'] : 'Modifier ' . $formData['name']) :
                            (app()->getLocale() == 'en' ? 'Create a new card' : 'Créer une nouvelle carte')); ?>

                    </h1>
                </div>

                <?php if($errors->any()): ?>
                    <?php if (isset($component)) { $__componentOriginal0296bf63334863c1b9c82a8f67a25f83 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal0296bf63334863c1b9c82a8f67a25f83 = $attributes; } ?>
<?php $component = App\View\Components\Alerte::resolve(['message' => app()->getLocale() == 'en' ? 'Please correct the errors below.' : 'Veuillez corriger les erreurs ci-dessous.','type' => 'danger','icon' => 'bi-exclamation-triangle'] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('alerte'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\Alerte::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal0296bf63334863c1b9c82a8f67a25f83)): ?>
<?php $attributes = $__attributesOriginal0296bf63334863c1b9c82a8f67a25f83; ?>
<?php unset($__attributesOriginal0296bf63334863c1b9c82a8f67a25f83); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal0296bf63334863c1b9c82a8f67a25f83)): ?>
<?php $component = $__componentOriginal0296bf63334863c1b9c82a8f67a25f83; ?>
<?php unset($__componentOriginal0296bf63334863c1b9c82a8f67a25f83); ?>
<?php endif; ?>
                    <ul class="mb-0 text-danger small">
                        <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <li><?php echo e($error); ?></li>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </ul>
                <?php endif; ?>

                <div class="row">
                    <div class="col-md-8">
                        <form action="<?php echo e($isEdit ? route('univers.update', $univers->id) : route('univers.store')); ?>" method="POST" enctype="multipart/form-data">
                            <?php echo csrf_field(); ?>
                            <?php if($isEdit): ?> <?php echo method_field('PUT'); ?> <?php endif; ?>

                            <div class="mb-3">
                                <label for="name" class="form-label fw-medium">
                                    <?php echo e(app()->getLocale() == 'en' ? 'Card name' : 'Nom de la carte'); ?> <span class="text-danger">*</span>
                                </label>
                                <input type="text" class="form-control <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                       id="name" name="name" value="<?php echo e($formData['name']); ?>" required
                                       placeholder="<?php echo e(app()->getLocale() == 'en' ? 'Ex: Universe 1' : 'Ex : Univers 1'); ?>">
                                <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <div class="invalid-feedback">
                                        <i class="bi bi-x-circle me-1"></i><?php echo e($message); ?>

                                    </div>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>

                            <div class="mb-3">
                                <label for="description" class="form-label fw-medium">
                                    <?php echo e(app()->getLocale() == 'en' ? 'Description' : 'Description'); ?> <span class="text-danger">*</span>
                                </label>
                                <textarea class="form-control <?php $__errorArgs = ['description'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                          id="description" name="description" rows="4" required><?php echo e($formData['description']); ?></textarea>
                                <?php $__errorArgs = ['description'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <div class="invalid-feedback">
                                        <i class="bi bi-x-circle me-1"></i><?php echo e($message); ?>

                                    </div>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                            <!--  Image DANS le formulaire -->
                            <?php if($isEdit && $formData['image']): ?>
                                <div class="mb-3">
                                    <label class="form-label fw-medium">Image actuelle</label>
                                    <div class="d-flex align-items-start gap-3">
                                        <img src="<?php echo e(asset('storage/' . $formData['image'])); ?>" alt="<?php echo e($formData['name']); ?>" class="img-thumbnail" style="width: 192px; height: 128px; object-fit: cover;">
                                        <button type="button" class="btn btn-outline-danger btn-sm" onclick="supprimerImage()">
                                            <i class="bi bi-trash me-1"></i>Supprimer l'image
                                        </button>
                                    </div>
                                </div>
                            <?php endif; ?>

                            <div class="mb-3">
                                <label for="image" class="form-label fw-medium"><?php echo e($isEdit ? 'Changer l\'image (optionnel)' : 'Image de la carte'); ?></label>
                                <input type="file" class="form-control <?php $__errorArgs = ['image'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="image" name="image" accept="image/*">
                                <?php $__errorArgs = ['image'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><div class="invalid-feedback"><?php echo e($message); ?></div><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                            <!--  Logo DANS le formulaire -->
                            <?php if($isEdit && $formData['logo']): ?>
                                <div class="mb-3">
                                    <label class="form-label fw-medium">Logo/Symbole actuel</label>
                                    <div class="d-flex align-items-start gap-3">
                                        <img src="<?php echo e(asset('storage/' . $formData['logo'])); ?>" alt="Logo" class="img-thumbnail" style="width: 64px; height: 64px; object-fit: cover;">
                                        <button type="button" class="btn btn-outline-danger btn-sm" onclick="supprimerLogo()">
                                            <i class="bi bi-trash me-1"></i>Supprimer le logo
                                        </button>
                                    </div>
                                </div>
                            <?php endif; ?>

                            <div class="mb-3">
                                <label for="logo" class="form-label fw-medium"><?php echo e($isEdit ? 'Changer le logo/symbole (optionnel)' : 'Logo/Symbole (optionnel)'); ?></label>
                                <input type="file" class="form-control <?php $__errorArgs = ['logo'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="logo" name="logo" accept="image/*">
                                <?php $__errorArgs = ['logo'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><div class="invalid-feedback"><?php echo e($message); ?></div><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                            <!--  Couleurs Primaire DANS le formulaire -->
                            <div class="row mb-3">
                                <div class="col-md-6">
                                    <label for="primary_color" class="form-label fw-medium">
                                        <?php echo e(app()->getLocale() == 'en' ? 'Primary color' : 'Couleur principale'); ?> <span class="text-danger">*</span>
                                    </label>
                                    <div class="input-group">
                                        <input type="color" class="form-control form-control-color <?php $__errorArgs = ['primary_color'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                               id="primary_color" name="primary_color" value="<?php echo e($formData['primary_color']); ?>" required>
                                        <span class="input-group-text">#</span>
                                        <input type="text" class="form-control <?php $__errorArgs = ['primary_color_hex'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                               id="primary_color_hex" name="primary_color_hex" value="<?php echo e($formData['primary_color_hex']); ?>" maxlength="6">
                                    </div>
                                </div>
                                <div class="col-md-6">
                                    <label for="secondary_color" class="form-label fw-medium">
                                        <?php echo e(app()->getLocale() == 'en' ? 'Secondary color' : 'Couleur secondaire'); ?> <span class="text-danger">*</span>
                                    </label>
                                    <div class="input-group">
                                        <input type="color" class="form-control form-control-color <?php $__errorArgs = ['secondary_color'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                               id="secondary_color" name="secondary_color" value="<?php echo e($formData['secondary_color']); ?>" required>
                                        <span class="input-group-text">#</span>
                                        <input type="text" class="form-control <?php $__errorArgs = ['secondary_color_hex'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                               id="secondary_color_hex" name="secondary_color_hex" value="<?php echo e($formData['secondary_color_hex']); ?>" maxlength="6">
                                    </div>
                                </div>
                            </div>

                            <div class="d-flex justify-content-between mt-4">
                                <?php if($isEdit): ?>
                                    <button type="button" class="btn btn-danger" onclick="confirmerSuppressionUnivers()">
                                        <i class="bi bi-trash"></i>
                                        <?php echo e(app()->getLocale() == 'en' ? 'Delete card' : 'Supprimer la carte'); ?>

                                    </button>
                                <?php endif; ?>
                                <div class="d-flex gap-2 <?php echo e(!$isEdit ? 'ms-auto' : ''); ?>">
                                    <a href="<?php echo e(url('/')); ?>" class="btn btn-secondary">
                                        <?php echo e(app()->getLocale() == 'en' ? 'Cancel' : 'Annuler'); ?>

                                    </a>
                                    <button type="submit" class="btn btn-primary">
                                        <i class="bi bi-<?php echo e($isEdit ? 'check-lg' : 'plus-lg'); ?>"></i>
                                        <?php echo e($isEdit ?
                                            (app()->getLocale() == 'en' ? 'Update card' : 'Modifier la carte') :
                                            (app()->getLocale() == 'en' ? 'Create card' : 'Créer la carte')); ?>

                                    </button>
                                </div>
                            </div>
                        </form>
                    </div>

                    <div class="col-md-4">
                        <div class="sticky-top" style="top: 2rem;">
                            <h5 class="fw-bold mb-3">
                                <?php echo e(app()->getLocale() == 'en' ? 'Live preview' : 'Aperçu en temps réel'); ?>

                            </h5>

                            <div id="preview" class="rounded-3 d-flex align-items-center justify-content-center text-white fw-bold fs-5 mb-3"
                                 style="height: 120px; background: <?php echo e($formData['gradients']['preview_main']); ?>;">
                                <?php echo e($formData['preview']['title']); ?>

                            </div>

                            <div class="card shadow-sm position-relative">
                                <div class="card-header border-0 text-white text-center py-2" id="preview-header" style="background: <?php echo e($formData['gradients']['preview_header']); ?>;">
                                    <h6 class="card-title mb-0 fw-bold" id="preview-title"><?php echo e($formData['preview']['title']); ?></h6>
                                </div>

                                <div id="preview-image-container" style="height: 150px; position: relative; overflow: hidden;">
                                    <?php if($formData['preview']['has_image']): ?>
                                        <img id="preview-image" src="<?php echo e($formData['preview']['image_url']); ?>" alt="Aperçu" style="width: 100%; height: 100%; object-fit: cover;">
                                    <?php else: ?>
                                        <div id="preview-image" class="d-flex align-items-center justify-content-center text-white fs-1 fw-bold h-100" style="background: <?php echo e($formData['gradients']['preview_image']); ?>;">
                                            <i class="bi bi-stars opacity-75"></i>
                                        </div>
                                    <?php endif; ?>
                                </div>

                                <div class="card-body p-3">
                                    <p class="card-text text-muted small mb-2" id="preview-description"><?php echo e($formData['preview']['description']); ?></p>
                                    <div class="d-flex align-items-center">
                                        <small class="text-muted me-2">Couleurs:</small>
                                        <div class="d-flex gap-1">
                                            <div class="rounded-circle border border-white shadow-sm" id="preview-primary-color" style="width: 20px; height: 20px; background-color: <?php echo e($formData['primary_color']); ?>;"></div>
                                            <div class="rounded-circle border border-white shadow-sm" id="preview-secondary-color" style="width: 20px; height: 20px; background-color: <?php echo e($formData['secondary_color']); ?>;"></div>
                                        </div>
                                    </div>
                                </div>

                                <?php if($formData['preview']['has_logo']): ?>
                                    <div class="position-absolute top-0 end-0 m-2" style="z-index: 10;" id="preview-logo-container">
                                        <img id="preview-logo" src="<?php echo e($formData['preview']['logo_url']); ?>" alt="Logo" class="rounded-circle border border-2 border-white shadow" style="width: 40px; height: 40px; object-fit: cover;">
                                    </div>
                                <?php else: ?>
                                    <div class="position-absolute top-0 end-0 m-2" style="z-index: 10;" id="preview-logo-container"></div>
                                <?php endif; ?>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<script>
const jsConfig = <?php echo json_encode($jsConfig, 15, 512) ?>;
<?php if($isEdit): ?>
const deleteRoutes = <?php echo json_encode($deleteRoutes, 15, 512) ?>;
<?php endif; ?>
</script>

<?php if($isEdit): ?>
<script>
// Fonctions de suppression avec confirmation
function confirmerSuppressionUnivers() {
    if (confirm('Êtes-vous sûr de vouloir supprimer cette carte ?')) {
        const form = document.createElement('form');
        form.method = 'POST';
        form.action = deleteRoutes.univers;
        form.appendChild(Object.assign(document.createElement('input'), {type: 'hidden', name: '_token', value: '<?php echo e(csrf_token()); ?>'}));
        form.appendChild(Object.assign(document.createElement('input'), {type: 'hidden', name: '_method', value: 'DELETE'}));
        document.body.appendChild(form);
        form.submit();
    }
}
// Fonctions de suppression d'image et de logo avec confirmation
function supprimerImage() {
    if (confirm('Êtes-vous sûr de vouloir supprimer l\'image ?')) {
        const form = document.createElement('form');
        form.method = 'POST';
        form.action = deleteRoutes.image;
        form.appendChild(Object.assign(document.createElement('input'), {type: 'hidden', name: '_token', value: '<?php echo e(csrf_token()); ?>'}));
        form.appendChild(Object.assign(document.createElement('input'), {type: 'hidden', name: '_method', value: 'DELETE'}));
        document.body.appendChild(form);
        form.submit();
    }
}
function supprimerLogo() {
    if (confirm('Êtes-vous sûr de vouloir supprimer le logo ?')) {
        const form = document.createElement('form');
        form.method = 'POST';
        form.action = deleteRoutes.logo;
        form.appendChild(Object.assign(document.createElement('input'), {type: 'hidden', name: '_token', value: '<?php echo e(csrf_token()); ?>'}));
        form.appendChild(Object.assign(document.createElement('input'), {type: 'hidden', name: '_method', value: 'DELETE'}));
        document.body.appendChild(form);
        form.submit();
    }
}
</script>
<?php endif; ?>

<script>
document.addEventListener('DOMContentLoaded', function() {
    const elements = Object.fromEntries(
        Object.entries(jsConfig.selectors).map(([key, selector]) => [key, document.querySelector(selector)])
    );

    function validateAndFormatHex(value) {
        return value.replace(/[^A-Fa-f0-9]/g, '').substring(0, jsConfig.validation.hex_max_length).toUpperCase();
    }

    function syncColorInputs(colorInput, hexInput) {
        colorInput.addEventListener('input', () => {
            hexInput.value = colorInput.value.substring(1).toUpperCase();
            updatePreview();
        });
        hexInput.addEventListener('input', () => {
            let hexValue = validateAndFormatHex(hexInput.value);
            hexInput.value = hexValue;
            if (hexValue.length === jsConfig.validation.hex_max_length) {
                colorInput.value = '#' + hexValue;
                updatePreview();
            }
        });
        hexInput.addEventListener('blur', () => {
            let hexValue = validateAndFormatHex(hexInput.value);
            if (hexValue.length < jsConfig.validation.hex_max_length) {
                hexValue = hexValue.padEnd(jsConfig.validation.hex_max_length, '0');
            }
            hexInput.value = hexValue;
            colorInput.value = '#' + hexValue;
            updatePreview();
        });
    }

    function updatePreview() {
        const name = elements.name_input?.value || jsConfig.preview.default_name;
        const description = elements.description_input?.value || jsConfig.preview.default_description;
        const primaryColor = elements.primary_color_input?.value;
        const secondaryColor = elements.secondary_color_input?.value;

        if (elements.preview) elements.preview.textContent = name;
        if (elements.preview) elements.preview.style.background = `linear-gradient(to right, ${primaryColor}, ${secondaryColor})`;
        if (elements.preview_title) elements.preview_title.textContent = name;
        if (elements.preview_description) {
            elements.preview_description.textContent = description.length > jsConfig.preview.description_limit ?
                description.substring(0, jsConfig.preview.description_limit) + '...' : description;
        }
        if (elements.preview_header) elements.preview_header.style.background = `linear-gradient(135deg, ${primaryColor} 0%, ${secondaryColor} 100%)`;

        if (elements.preview_primary_color) elements.preview_primary_color.style.backgroundColor = primaryColor;
        if (elements.preview_secondary_color) elements.preview_secondary_color.style.backgroundColor = secondaryColor;
        if (elements.preview_image && elements.preview_image.tagName === 'DIV') {
            elements.preview_image.style.background = `linear-gradient(45deg, ${primaryColor} 0%, ${secondaryColor} 100%)`;
        }
    }

    function previewFile(input, targetContainer, isLogo = false) {
        if (input.files && input.files[0]) {
            const reader = new FileReader();
            reader.onload = (e) => {
                if (isLogo) {
                    let logoImg = targetContainer.querySelector('#preview-logo');
                    if (!logoImg) {
                        logoImg = Object.assign(document.createElement('img'), {
                            id: 'preview-logo',
                            className: 'rounded-circle border border-2 border-white shadow',
                            alt: 'Logo'
                        });
                        logoImg.style.cssText = 'width: 40px; height: 40px; object-fit: cover;';
                        targetContainer.appendChild(logoImg);
                    }
                    logoImg.src = e.target.result;
                } else {
                    targetContainer.innerHTML = `<img src="${e.target.result}" alt="Aperçu" style="width: 100%; height: 100%; object-fit: cover;">`;
                }
            };
            reader.readAsDataURL(input.files[0]);
        }
    }

    if (elements.preview) {
        syncColorInputs(elements.primary_color_input, elements.primary_color_hex_input);
        syncColorInputs(elements.secondary_color_input, elements.secondary_color_hex_input);

        elements.name_input?.addEventListener('input', updatePreview);
        elements.description_input?.addEventListener('input', updatePreview);
        elements.image_input?.addEventListener('change', () => previewFile(elements.image_input, elements.preview_image_container));
        elements.logo_input?.addEventListener('change', () => previewFile(elements.logo_input, elements.preview_logo_container, true));

        updatePreview();
    }
});
</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\code\Projet_1\resources\views/univers/form.blade.php ENDPATH**/ ?>