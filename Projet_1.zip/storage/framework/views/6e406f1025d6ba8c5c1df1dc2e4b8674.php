<?php $__env->startSection('title', $viewConfig['messages']['title']); ?>
<?php $__env->startSection('content'); ?>

<!-- Bouton de retour -->
<div class="mb-4">
    <a href="<?php echo e(url('/')); ?>" class="btn btn-outline-secondary">
        <i class="bi bi-arrow-left me-2"></i>
        <?php echo e(app()->getLocale() == 'en' ? 'Back to collection' : 'Retour à la collection'); ?>

    </a>
</div>

<div class="text-center mb-5">
    <h1 class="display-4 fw-bold text-dark mb-2">
        <i class="bi bi-heart-fill text-danger me-3"></i>
        <?php echo e($viewConfig['messages']['title']); ?>

    </h1>
    <p class="lead text-muted">
        <?php echo e($viewConfig['messages']['subtitle']); ?>

    </p>
    
    <?php if($processedUnivers->isNotEmpty()): ?>
        <div class="mt-3">
            <span class="badge bg-danger fs-6 px-3 py-2">
                <?php echo e($processedUnivers->count()); ?> <?php echo e(app()->getLocale() == 'en' ? 'favorite cards' : 'cartes favorites'); ?>

            </span>
        </div>
    <?php endif; ?>
</div>

<div class="row g-4">
    <?php $__empty_1 = true; $__currentLoopData = $processedUnivers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $univers): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
    <div class="col-md-6 col-lg-4">
        <?php if (isset($component)) { $__componentOriginal92e75aaf20b8ba8b153e8e2ef5cb67a0 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal92e75aaf20b8ba8b153e8e2ef5cb67a0 = $attributes; } ?>
<?php $component = App\View\Components\Carte::resolve(['id' => $univers['id'],'name' => $univers['name'],'gradientHeader' => $univers['gradient_header'],'imageUrl' => $univers['image_url'],'cardImageHeight' => $viewConfig['styles']['card_image_height'],'gradientBackground' => $univers['gradient_background'],'description' => $univers['truncated_description'],'primaryColor' => $univers['primary_color'],'secondaryColor' => $univers['secondary_color'],'colorIndicatorSize' => $viewConfig['styles']['color_indicator_size'],'colorTooltipPrimary' => $univers['color_tooltips']['primary'],'colorTooltipSecondary' => $univers['color_tooltips']['secondary'],'logoUrl' => $univers['logo_url'],'logoSize' => $viewConfig['styles']['logo_size']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('carte'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\Carte::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal92e75aaf20b8ba8b153e8e2ef5cb67a0)): ?>
<?php $attributes = $__attributesOriginal92e75aaf20b8ba8b153e8e2ef5cb67a0; ?>
<?php unset($__attributesOriginal92e75aaf20b8ba8b153e8e2ef5cb67a0); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal92e75aaf20b8ba8b153e8e2ef5cb67a0)): ?>
<?php $component = $__componentOriginal92e75aaf20b8ba8b153e8e2ef5cb67a0; ?>
<?php unset($__componentOriginal92e75aaf20b8ba8b153e8e2ef5cb67a0); ?>
<?php endif; ?>
    </div>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
    <div class="col-12">
        <div class="text-center mt-5">
            <div class="mb-4">
                <i class="bi bi-heart display-1 text-muted"></i>
            </div>
            <h3 class="text-muted mb-3"><?php echo e($viewConfig['messages']['empty_title']); ?></h3>
            <p class="text-muted mb-4"><?php echo e($viewConfig['messages']['empty_subtitle']); ?></p>
            <a href="<?php echo e(url('/')); ?>" class="btn btn-primary btn-lg">
                <i class="bi bi-arrow-left me-2"></i>
                <?php echo e(app()->getLocale() == 'en' ? 'Browse Cards' : 'Parcourir les cartes'); ?>

            </a>
        </div>
    </div>
    <?php endif; ?>
</div>

<!-- Actions supplémentaires quand il y a des favoris -->
<?php if($processedUnivers->isNotEmpty()): ?>
    <div class="text-center mt-5 pt-4 border-top">
        <div class="d-flex justify-content-center gap-3 flex-wrap">
            <a href="<?php echo e(url('/')); ?>" class="btn btn-outline-primary">
                <i class="bi bi-collection me-2"></i>
                <?php echo e(app()->getLocale() == 'en' ? 'View all cards' : 'Voir toutes les cartes'); ?>

            </a>
            
            <?php if(Auth::user()->isA('admin') || true): ?>
                <a href="<?php echo e(route('univers.create')); ?>" class="btn btn-primary">
                    <i class="bi bi-plus-lg me-2"></i>
                    <?php echo e(app()->getLocale() == 'en' ? 'Create new card' : 'Créer une nouvelle carte'); ?>

                </a>
            <?php endif; ?>
        </div>
    </div>
<?php endif; ?>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\code\Projet_1\resources\views/favorites/index.blade.php ENDPATH**/ ?>