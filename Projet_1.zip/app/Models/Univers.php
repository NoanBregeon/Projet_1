<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

/**
 * App\Models\Univers
 *
 * @property int $id
 * @property string $name
 * @property string|null $description
 * @property string|null $image
 * @property string|null $logo
 * @property string $primary_color
 * @property string $secondary_color
 * @property \Illuminate\Support\Carbon|null $created_at
 * @property \Illuminate\Support\Carbon|null $updated_at
 * @property \Illuminate\Support\Carbon|null $deleted_at
 */
class Univers extends Model
{
    use HasFactory;

    protected $table = 'univers';

    /**
     * Mass assignable attributes.
     */
    protected $fillable = [
        'name',
        'description',
        'image',
        'logo',
        'primary_color',
        'secondary_color',
    ];

    protected $casts = [
        'deleted_at' => 'datetime',
    ];

    /**
     * Users who have this univers as favorite.
     */
    public function favoriteUsers()
    {
        return $this->belongsToMany(User::class, 'favorites');
    }

    /**
     * Helper to count favorites.
     */
    public function favoritesCount(): int
    {
        return $this->favoriteUsers()->count();
    }
}
